package net.salemfornet.shabkatiwifi

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.wifi.WifiManager
import android.os.Build
import android.content.Context

class MainActivity: FlutterActivity() {
    private val CHANNEL = "shabkati/gateway"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "getDhcpGateway") {
                val gateway = getGatewayIp()
                result.success(gateway)
            } else {
                result.notImplemented()
            }
        }
    }

    private fun getGatewayIp(): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val network = cm.activeNetwork ?: return null
                val props: LinkProperties = cm.getLinkProperties(network) ?: return null
                val routes = props.routes
                val gw = routes.firstOrNull { it.gateway != null }?.gateway?.hostAddress
                gw
            } else {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val dhcp = wm.dhcpInfo ?: return null
                val ip = dhcp.gateway
                val b1 = (ip and 0xFF)
                val b2 = (ip shr 8 and 0xFF)
                val b3 = (ip shr 16 and 0xFF)
                val b4 = (ip shr 24 and 0xFF)
                "${b1}.${b2}.${b3}.${b4}"
            }
        } catch (e: Exception) {
            null
        }
    }
}
