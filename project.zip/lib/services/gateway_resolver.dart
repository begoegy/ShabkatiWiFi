import 'package:flutter/services.dart';

class GatewayResolver {
  static const MethodChannel _ch = MethodChannel('shabkati/gateway');

  static Future<String?> getDhcpGateway() async {
    try {
      final res = await _ch.invokeMethod<String>('getDhcpGateway');
      return res;
    } catch (_) {
      return null;
    }
  }
}
