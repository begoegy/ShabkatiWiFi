import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class Secure {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static Future<void> saveCredentials(String host, String user, String pass) async {
    await _storage.write(key: 'host', value: host);
    await _storage.write(key: 'user', value: user);
    await _storage.write(key: 'pass', value: pass);
  }

  static Future<(String?, String?, String?)> loadCredentials() async {
    final h = await _storage.read(key: 'host');
    final u = await _storage.read(key: 'user');
    final p = await _storage.read(key: 'pass');
    return (h, u, p);
  }
}
