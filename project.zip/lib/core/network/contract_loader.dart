import 'dart:convert';
import 'package:yaml/yaml.dart';
import 'package:flutter/services.dart' show rootBundle;

class StrictContract {
  final Map data;
  StrictContract(this.data);

  static Future<StrictContract> load() async {
    final text = await rootBundle.loadString('assets/router/tomato_contract.yaml');
    final y = loadYaml(text);
    final map = jsonDecode(jsonEncode(y)) as Map<String, dynamic>;
    return StrictContract(map);
  }

  Map get meta => data['meta'] ?? {};
  Map get network => data['network'] ?? {};
  Map get session => data['session'] ?? {};
  Map get wifi => data['wifi'] ?? {};
  Map get devices => data['devices'] ?? {};
  Map get clientLimit => data['client_limit'] ?? {};
  Map get errors => data['errors'] ?? {};
}
