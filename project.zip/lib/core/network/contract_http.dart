import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:cookie_jar/cookie_jar.dart';

class ContractHttp {
  final Dio dio;
  final CookieJar jar;
  ContractHttp._(this.dio, this.jar);

  static ContractHttp create({required String baseUrl, int connectMs=10000, int readMs=15000}) {
    final dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: Duration(milliseconds: connectMs),
      receiveTimeout: Duration(milliseconds: readMs),
      sendTimeout: Duration(milliseconds: readMs),
      followRedirects: true,
      validateStatus: (s) => s != null && s >= 200 && s < 400,
    ));
    final jar = CookieJar();
    dio.interceptors.add(CookieManager(jar));
    return ContractHttp._(dio, jar);
  }

  Future<Response<String>> getText(String path, {Map<String, dynamic>? headers}) async {
    return await dio.get<String>(path, options: Options(responseType: ResponseType.plain, headers: headers));
  }

  Future<Response<String>> postForm(String path, Map<String, String> body, {Map<String, dynamic>? headers}) async {
    final data = body.entries.map((e) => '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}').join('&');
    return await dio.post<String>(path, data: data, options: Options(
      responseType: ResponseType.plain,
      headers: headers,
      contentType: Headers.formUrlEncodedContentType,
    ));
  }

  static String? firstMatch(List<String> patterns, String text) {
    for (final p in patterns) {
      final re = RegExp(p, multiLine: true, dotAll: true);
      final m = re.firstMatch(text);
      if (m != null && m.groupCount >= 1) {
        return m.group(1);
      }
    }
    return null;
  }
}
