import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../wifi/controllers/wifi_controller.dart';
import '../../clients/controllers/clients_controller.dart';
import '../../settings/presentation/about_button.dart';

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final wifi = ref.watch(wifiControllerProvider);
    final clients = ref.watch(clientsControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم – Shabkati WiFi'), actions: const [AboutButton()]),
      body: RefreshIndicator(
        onRefresh: () async {
          await ref.read(wifiControllerProvider.notifier).refresh();
          await ref.read(clientsControllerProvider.notifier).refresh();
        },
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Text('الشبكة', textAlign: TextAlign.right, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('SSID: ${wifi.ssid ?? '—'}', textAlign: TextAlign.right),
                  Text('البث: ${wifi.hidden == true ? 'مخفي' : 'ظاهر'}', textAlign: TextAlign.right),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    onPressed: () => ref.read(wifiControllerProvider.notifier).readBack(),
                    icon: const Icon(Icons.sync),
                    label: const Text('قراءة الآن'),
                  ),
                ]),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Text('الأجهزة', textAlign: TextAlign.right, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('إجمالي: ${clients.total} | نشط: ${clients.active} | محظور: ${clients.blocked}', textAlign: TextAlign.right),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    onPressed: () => ref.read(clientsControllerProvider.notifier).refresh(),
                    icon: const Icon(Icons.devices),
                    label: const Text('إظهار الأجهزة / تحديث'),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: () => ref.read(wifiControllerProvider.notifier).applyBatch(),
              icon: const Icon(Icons.save),
              label: const Text('حفظ (دفعة واحدة)'),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => ref.read(wifiControllerProvider.notifier).reboot(),
              icon: const Icon(Icons.restart_alt),
              label: const Text('إعادة تشغيل الراوتر'),
            ),
            const SizedBox(height: 32),
            const Center(child: Text('© 2025 SalemForNet. جميع الحقوق محفوظة.')),
          ],
        ),
      ),
    );
  }
}
