import 'package:flutter_riverpod/flutter_riverpod.dart';

class WifiState {
  final String? ssid;
  final bool? hidden;
  final String? password;
  final int? clientLimit;
  final bool saving;
  const WifiState({this.ssid, this.hidden, this.password, this.clientLimit, this.saving=false});

  WifiState copyWith({String? ssid, bool? hidden, String? password, int? clientLimit, bool? saving}) =>
      WifiState(
        ssid: ssid ?? this.ssid,
        hidden: hidden ?? this.hidden,
        password: password ?? this.password,
        clientLimit: clientLimit ?? this.clientLimit,
        saving: saving ?? this.saving,
      );
}

class WifiController extends StateNotifier<WifiState> {
  WifiController(): super(const WifiState());

  Future<void> refresh() async {
    // TODO: connect TomatoDriver via provider and read
  }

  Future<void> readBack() async { await refresh(); }

  Future<void> applyBatch() async {
    state = state.copyWith(saving: true);
    try {
      // TODO: assemble ChangeSet and call driver.applyChanges
    } finally {
      state = state.copyWith(saving: false);
    }
  }

  Future<void> reboot() async {
    // Contract has no reboot; show message via UI layer
  }
}

final wifiControllerProvider = StateNotifierProvider<WifiController, WifiState>((ref) => WifiController());
