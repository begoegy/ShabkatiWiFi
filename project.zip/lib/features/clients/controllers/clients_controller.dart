import 'package:flutter_riverpod/flutter_riverpod.dart';

class ClientsState {
  final int total;
  final int active;
  final int blocked;
  final bool loading;
  const ClientsState({this.total=0, this.active=0, this.blocked=0, this.loading=false});

  ClientsState copyWith({int? total, int? active, int? blocked, bool? loading}) =>
      ClientsState(
        total: total ?? this.total,
        active: active ?? this.active,
        blocked: blocked ?? this.blocked,
        loading: loading ?? this.loading,
      );
}

class ClientsController extends StateNotifier<ClientsState> {
  ClientsController(): super(const ClientsState());

  Future<void> refresh() async {
    state = state.copyWith(loading: true);
    try {
      // TODO: fetch listClients via driver, then compute totals
    } finally {
      state = state.copyWith(loading: false);
    }
  }
}

final clientsControllerProvider = StateNotifierProvider<ClientsController, ClientsState>((ref) => ClientsController());
