import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../services/gateway_resolver.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:go_router/go_router.dart';

class LandingPage extends ConsumerStatefulWidget {
  const LandingPage({super.key});
  @override
  ConsumerState<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends ConsumerState<LandingPage> {
  String? gateway;
  bool resolving = true;
  final controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _resolveGateway();
  }

  Future<void> _resolveGateway() async {
    setState(() => resolving = true);
    await Permission.location.request();
    final g = await GatewayResolver.getDhcpGateway();
    setState(() {
      gateway = g;
      controller.text = g ?? '';
      resolving = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الاتصال بالشبكة – SalemForNet'), centerTitle: true),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (resolving) const LinearProgressIndicator(),
            const SizedBox(height: 12),
            Text('✅ الجيتواي (اكتشاف تلقائي خلال ثوانٍ):', textAlign: TextAlign.right),
            const SizedBox(height: 8),
            TextField(
              textDirection: TextDirection.ltr,
              controller: controller,
              decoration: const InputDecoration(labelText: 'Gateway IP', hintText: '192.168.1.1'),
            ),
            const SizedBox(height: 12),
            Wrap(
              alignment: WrapAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  onPressed: _resolveGateway,
                  icon: const Icon(Icons.wifi_find),
                  label: const Text('اكتشف تلقائيًا'),
                ),
                ElevatedButton.icon(
                  onPressed: () => context.go('/login', extra: controller.text.trim()),
                  icon: const Icon(Icons.navigate_next),
                  label: const Text('متابعة'),
                ),
              ],
            ),
            const Spacer(),
            const Text('© 2025 SalemForNet. جميع الحقوق محفوظة.', textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
