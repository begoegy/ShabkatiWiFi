import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/security/secure_storage.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});
  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _host = TextEditingController();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _obscure = true;
  bool _loading = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final hostArg = GoRouterState.of(context).extra as String?;
    if (hostArg != null) _host.text = hostArg;
  }

  Future<void> _saveAndContinue() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await Secure.saveCredentials(_host.text.trim(), _user.text.trim(), _pass.text);
      if (mounted) context.go('/dashboard');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول – الراوتر')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                textDirection: TextDirection.ltr,
                controller: _host,
                decoration: const InputDecoration(labelText: 'عنوان الراوتر (Host/IP)'),
                validator: (v) => (v==null || v.isEmpty) ? 'أدخل عنوان الراوتر' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                textDirection: TextDirection.ltr,
                controller: _user,
                decoration: const InputDecoration(labelText: 'اسم المستخدم'),
                validator: (v) => (v==null || v.isEmpty) ? 'أدخل اسم المستخدم' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                textDirection: TextDirection.ltr,
                controller: _pass,
                decoration: InputDecoration(
                  labelText: 'كلمة المرور',
                  suffixIcon: IconButton(
                    onPressed: () => setState(() => _obscure = !_obscure),
                    icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                  ),
                ),
                obscureText: _obscure,
                validator: (v) => (v==null || v.isEmpty) ? 'أدخل كلمة المرور' : null,
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _loading ? null : _saveAndContinue,
                icon: _loading ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.lock_open),
                label: const Text('دخول وحفظ آمن'),
              ),
              const SizedBox(height: 24),
              const Text('لا يتم إرسال معلوماتك لأي خادم خارجي. التخزين محلي وآمن.', textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
