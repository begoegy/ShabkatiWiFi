import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AboutButton extends StatelessWidget {
  const AboutButton({super.key});
  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () => context.go('/about'),
      icon: const Icon(Icons.info_outline),
      tooltip: 'حول التطبيق',
    );
  }
}
