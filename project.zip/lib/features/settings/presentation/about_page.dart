import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});
  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  String privacy = '';
  String eula = '';

  Future<void> _load() async {
    final p = await rootBundle.loadString('assets/legal/privacy_ar.md');
    final e = await rootBundle.loadString('assets/legal/eula_ar.md');
    setState(() { privacy = p; eula = e; });
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('حول التطبيق – SalemForNet'),
          bottom: const TabBar(tabs: [Tab(text: 'الخصوصية'), Tab(text: 'الشروط')]),
        ),
        body: TabBarView(children: [
          SingleChildScrollView(padding: const EdgeInsets.all(16), child: Text(privacy, textDirection: TextDirection.rtl)),
          SingleChildScrollView(padding: const EdgeInsets.all(16), child: Text(eula, textDirection: TextDirection.rtl)),
        ]),
      ),
    );
  }
}
