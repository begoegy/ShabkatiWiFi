enum LinkType { wifi, lan }

class RouterClient {
  final String name;
  final String mac;
  final String ip;
  final LinkType linkType;
  final bool blocked;
  RouterClient({required this.name, required this.mac, required this.ip, required this.linkType, required this.blocked});
}

class ChangeSet {
  String? ssid;
  bool? hidden;
  String? wifiPassword;
  int? clientLimit;
  final List<String> blockMacs = [];
  final List<String> unblockMacs = [];
  bool get isEmpty => ssid==null && hidden==null && wifiPassword==null && clientLimit==null && blockMacs.isEmpty && unblockMacs.isEmpty;
}

abstract class RouterDriver {
  Future<void> initialize({required String host, required String username, required String password});
  Future<String> getSSID();
  Future<void> setSSID(String name);
  Future<bool> getBroadcastHidden();
  Future<void> setBroadcastHidden(bool hidden);
  Future<String> getWifiPassword();
  Future<void> setWifiPassword(String password);
  Future<List<RouterClient>> listClients();
  Future<void> blockClient(String mac);
  Future<void> unblockClient(String mac);
  Future<int> getClientLimit();
  Future<void> setClientLimit(int limit);
  Future<void> applyChanges(ChangeSet changes);
  Future<void> reboot();
}
