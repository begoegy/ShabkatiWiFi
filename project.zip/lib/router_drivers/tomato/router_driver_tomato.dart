import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import '../../core/network/contract_loader.dart';
import '../../core/network/contract_http.dart';
import '../router_driver.dart';

class TomatoDriver implements RouterDriver {
  late StrictContract _c;
  late ContractHttp _http;
  String? _httpId;
  late String _base;

  @override
  Future<void> initialize({required String host, required String username, required String password}) async {
    _c = await StrictContract.load();
    _base = 'http://$host';

    final timeouts = _c.network['timeouts'] ?? {};
    final connectMs = ((timeouts['connect_seconds'] ?? 10) * 1000).toInt();
    final readMs = ((timeouts['read_seconds'] ?? 15) * 1000).toInt();
    _http = ContractHttp.create(baseUrl: _base, connectMs: connectMs, readMs: readMs);

    // Establish session cookies by visiting known pages
    final List paths = (_c.network['auth']?['steps']?[0]?['paths'] ?? ['/']).cast<String>();
    for (final p in paths) { try { await _http.getText(p); } catch (_) {} }

    // Extract http_id
    _httpId = await _extractHttpId();
    if (_httpId == null || _httpId!.isEmpty) {
      throw Exception(_c.errors['http_id_missing'] ?? 'HTTP_ID_NOT_FOUND');
    }
  }

  Future<String?> _extractHttpId() async {
    final List sources = _c.session['http_id']?['sources'] ?? [];
    final List patterns = _c.session['http_id']?['regex'] ?? [];
    for (final s in sources) {
      try {
        final method = (s['method'] ?? 'GET') as String;
        final path = s['path'] as String;
        Response<String> resp;
        if (method == 'GET') resp = await _http.getText(path);
        else resp = await _http.postForm(path, {});
        final text = resp.data ?? '';
        final id = ContractHttp.firstMatch(patterns.cast<String>(), text);
        if (id != null && id.isNotEmpty) return id;
      } catch (_) {}
    }
    return null;
  }

  // READ WIFI
  Future<({String ssid, String hidden, String? akm, String? crypto})> _readWifi() async {
    final Map wifi = _c.wifi;
    final List sources = wifi['read']?['sources'] ?? [];
    String? content;
    final headers = (_c.network['headers']?['xhr'] ?? {}) as Map;
    final hdrs = headers.map((k, v) => MapEntry(k.toString(), (v as String).replaceAll('\${BASE}', _base)));

    for (final s in sources) {
      try {
        final method = (s['method'] ?? 'GET') as String;
        final path = s['path'] as String;
        final body = (s['body'] as String?)?.replaceAll('\${http_id}', _httpId ?? '');
        Response<String> r;
        if (method == 'POST') r = await _http.postForm(path, _formToMap(body ?? ''), headers: hdrs);
        else r = await _http.getText(path, headers: hdrs);
        final t = r.data ?? '';
        if (t.isNotEmpty) { content = t; break; }
      } catch (_) {}
    }
    if (content == null) throw Exception(_c.errors['parse_failed'] ?? 'PARSE_FAILED');

    String ssid = _matchFirst(wifi['read']['parse']['ssid']['prefer_order'], content) ?? '<unknown>';
    String hidden = _matchFirst(wifi['read']['parse']['hidden']['prefer_order'], content) ?? '?';
    String? akm = _matchFirst(wifi['read']['parse']['akm_optional'] ?? [], content);
    String? crypto = _matchFirst(wifi['read']['parse']['crypto_optional'] ?? [], content);
    return (ssid: ssid, hidden: hidden, akm: akm, crypto: crypto);
  }

  String? _matchFirst(dynamic patterns, String text) {
    if (patterns is List) return ContractHttp.firstMatch(patterns.cast<String>(), text);
    return null;
  }

  Map<String, String> _formToMap(String form) {
    final map = <String, String>{};
    if (form.isEmpty) return map;
    for (final part in form.split('&')) {
      if (part.trim().isEmpty) continue;
      final kv = part.split('=');
      final k = Uri.decodeQueryComponent(kv[0]);
      final v = kv.length > 1 ? Uri.decodeQueryComponent(kv.sublist(1).join('=')) : '';
      map[k] = v;
    }
    return map;
  }

  @override
  Future<String> getSSID() async => (await _readWifi()).ssid;

  @override
  Future<bool> getBroadcastHidden() async {
    final r = await _readWifi();
    return r.hidden == '1';
  }

  @override
  Future<String> getWifiPassword() async => ''; // not exposed per STRICT contract

  @override
  Future<void> setSSID(String name) async {
    final cur = await _readWifi();
    await _saveWifi(ssid: name, hidden: cur.hidden == '1', password: null);
  }

  @override
  Future<void> setBroadcastHidden(bool hidden) async {
    final cur = await _readWifi();
    await _saveWifi(ssid: cur.ssid, hidden: hidden, password: null);
  }

  @override
  Future<void> setWifiPassword(String password) async {
    if (password.length < 8) throw Exception('كلمة المرور يجب ألا تقل عن 8 أحرف.');
    final cur = await _readWifi();
    await _saveWifi(ssid: cur.ssid, hidden: cur.hidden == '1', password: password);
  }

  Future<void> _saveWifi({required String ssid, required bool hidden, String? password}) async {
    final Map write = _c.wifi['write'] ?? {};
    final path = write['path'] as String;
    final headers = (_c.network['headers']?['xhr'] ?? {}) as Map;
    final hdrs = headers.map((k,v)=>MapEntry(k.toString(), (v as String).replaceAll('\${BASE}', _base)));
    final Map<String, String> body = {};
    final Map fields = write['body_fields'] ?? {};
    fields.forEach((k, v) {
      var val = (v as String);
      val = val.replaceAll('\${http_id}', _httpId ?? '');
      val = val.replaceAll('\${ssid}', ssid);
      val = val.replaceAll('\${hidden}', hidden ? '1' : '0');
      val = val.replaceAll('\${password}', password ?? '');
      body[k.toString()] = val;
    });
    final r = await _http.postForm(path, body, headers: hdrs);
    if ((r.data ?? '').isEmpty) throw Exception(_c.errors['parse_failed'] ?? 'PARSE_FAILED');

    final List after = write['after'] ?? [];
    for (final a in after) {
      final apath = a['path'] as String;
      final Map afields = (a['body_fields'] ?? {});
      final Map<String, String> abody = {};
      afields.forEach((k, v) {
        var val = (v as String).replaceAll('\${http_id}', _httpId ?? '');
        abody[k.toString()] = val;
      });
      await _http.postForm(apath, abody, headers: hdrs);
      final wait = (a['wait_seconds'] ?? 8).toInt();
      await Future.delayed(Duration(seconds: wait));
    }
    final afterState = await _readWifi();
    if (afterState.ssid != ssid) throw Exception('فشل تطبيق الاسم الجديد للشبكة.');
    if ((hidden ? '1' : '0') != afterState.hidden) throw Exception('فشل تطبيق حالة بث الشبكة.');
  }

  @override
  Future<List<RouterClient>> listClients() async {
    final Map dev = _c.devices;
    final List seq = dev['read_sequence'] ?? [];
    final headers = (_c.network['headers']?['xhr'] ?? {}) as Map;
    final hdrs = headers.map((k,v)=>MapEntry(k.toString(), (v as String).replaceAll('\${BASE}', _base)));
    String? payload;
    for (final step in seq) {
      final path = step['path'] as String;
      final bodyStr = (step['body'] as String).replaceAll('\${http_id}', _httpId ?? '');
      final body = _formToMap(bodyStr);
      try {
        final r = await _http.postForm(path, body, headers: hdrs);
        final t = r.data ?? '';
        if (t.trim().isNotEmpty) { payload = t; break; }
      } catch (_) {}
    }
    if (payload == null) throw Exception(_c.errors['parse_failed'] ?? 'PARSE_FAILED');

    final String text = payload;
    final String? inner = _tryWrapper(dev['parse']?['wrapper_regex'], text);
    final String jsonLike = inner ?? text;
    final List<RouterClient> devices = _tryJsonOrHtml(dev, jsonLike);
    final seen = <String>{};
    final unique = <RouterClient>[];
    for (final d in devices) {
      final macU = d.mac.toUpperCase();
      if (!seen.contains(macU)) { seen.add(macU); unique.add(d); }
    }
    return unique;
  }

  String? _tryWrapper(dynamic pattern, String text) {
    if (pattern is String && pattern.isNotEmpty) {
      final re = RegExp(pattern, multiLine: true, dotAll: true);
      final m = re.firstMatch(text);
      if (m != null && m.groupCount >= 1) return m.group(1)!;
    }
    return null;
  }

  List<RouterClient> _tryJsonOrHtml(Map dev, String text) {
    final trim = text.trim();
    if (trim.startsWith('[') || trim.startsWith('{')) {
      try {
        final data = jsonDecode(trim);
        return _mapCandidates(dev['parse']?['mapping'], data);
      } catch (_) {}
    }
    return _parseHtmlFallback(dev['parse']?['html_fallback'], text);
  }

  List<RouterClient> _mapCandidates(Map? mapping, dynamic data) {
    final macKeys = (mapping?['mac_candidates'] ?? ['mac','MAC',2]) as List;
    final ipKeys = (mapping?['ip_candidates'] ?? ['ip','IP',1]) as List;
    final nameKeys = (mapping?['name_candidates'] ?? ['name','Name',0]) as List;

    final list = <RouterClient>[];
    if (data is List) {
      for (final item in data) {
        final mac = _pick(item, macKeys);
        if (mac == null) continue;
        final ip = _pick(item, ipKeys);
        final name = _pick(item, nameKeys);
        list.add(RouterClient(name: (name ?? '').toString(), mac: mac.toString().toUpperCase(), ip: (ip ?? '').toString(), linkType: LinkType.wifi, blocked: false));
      }
    } else if (data is Map) {
      data.forEach((_, item) {
        final mac = _pick(item, macKeys);
        if (mac == null) return;
        final ip = _pick(item, ipKeys);
        final name = _pick(item, nameKeys);
        list.add(RouterClient(name: (name ?? '').toString(), mac: mac.toString().toUpperCase(), ip: (ip ?? '').toString(), linkType: LinkType.wifi, blocked: false));
      });
    }
    return list;
  }

  dynamic _pick(dynamic item, List keys) {
    if (item is Map) {
      for (final k in keys) {
        if (k is String && item.containsKey(k)) return item[k];
      }
    } else if (item is List) {
      for (final k in keys) {
        if (k is int && k < item.length) return item[k];
      }
    }
    return null;
  }

  List<RouterClient> _parseHtmlFallback(Map? spec, String text) {
    final macRe = RegExp((spec?['mac'] ?? r'([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})'), multiLine: true);
    final ipRe = RegExp((spec?['ip'] ?? r'\b\d{1,3}(?:\.\d{1,3}){3}\b'), multiLine: true);
    final macs = macRe.allMatches(text).map((m)=>m.group(1)!.toUpperCase()).toList();
    final ips = ipRe.allMatches(text).map((m)=>m.group(0)!).toList();
    final list = <RouterClient>[];
    for (int i=0; i<macs.length; i++) {
      final mac = macs[i];
      final ip = (i < ips.length) ? ips[i] : '';
      list.add(RouterClient(name: '', mac: mac, ip: ip, linkType: LinkType.wifi, blocked: false));
    }
    return list;
  }

  @override
  Future<void> blockClient(String mac) async {
    throw Exception(_c.errors['mac_filter_unstable'] ?? 'FEATURE_UNSUPPORTED');
  }

  @override
  Future<void> unblockClient(String mac) async {
    throw Exception(_c.errors['mac_filter_unstable'] ?? 'FEATURE_UNSUPPORTED');
  }

  @override
  Future<int> getClientLimit() async {
    final List sources = _c.wifi['read']?['sources'] ?? [];
    for (final s in sources) {
      try {
        final method = (s['method'] ?? 'GET') as String;
        final path = s['path'] as String;
        final body = (s['body'] as String?)?.replaceAll('\${http_id}', _httpId ?? '');
        Response<String> r;
        if (method == 'POST') r = await _http.postForm(path, _formToMap(body ?? ''), headers: {});
        else r = await _http.getText(path);
        final text = r.data ?? '';
        final List patterns = (_c.clientLimit['read']?['regex'] ?? []) as List;
        final match = ContractHttp.firstMatch(patterns.cast<String>(), text);
        if (match != null) return int.tryParse(match) ?? 0;
      } catch (_) {}
    }
    return 0;
  }

  @override
  Future<void> setClientLimit(int limit) async {
    final Map cl = _c.clientLimit;
    final write = cl['write'] ?? {};
    final path = write['path'] as String;
    final headers = (_c.network['headers']?['xhr'] ?? {}) as Map;
    final hdrs = headers.map((k,v)=>MapEntry(k.toString(), (v as String).replaceAll('\${BASE}', _base)));
    final fields = (write['body_fields'] ?? {}) as Map;
    final body = <String, String>{};
    fields.forEach((k, v) {
      var val = (v as String).replaceAll('\${http_id}', _httpId ?? '');
      val = val.replaceAll('\${limit}', limit.toString());
      body[k.toString()] = val;
    });
    await _http.postForm(path, body, headers: hdrs);
    final List after = write['after'] ?? [];
    for (final a in after) {
      final apath = a['path'] as String;
      final Map afields = (a['body_fields'] ?? {});
      final Map<String, String> abody = {};
      afields.forEach((k, v) {
        var val = (v as String).replaceAll('\${http_id}', _httpId ?? '');
        abody[k.toString()] = val;
      });
      await _http.postForm(apath, abody, headers: hdrs);
      final wait = (a['wait_seconds'] ?? 8).toInt();
      await Future.delayed(Duration(seconds: wait));
    }
  }

  @override
  Future<void> applyChanges(ChangeSet changes) async {
    if (changes.isEmpty) return;
    final cur = await _readWifi();
    final newSsid = changes.ssid ?? cur.ssid;
    final newHidden = changes.hidden ?? (cur.hidden == '1');
    final newPass = changes.wifiPassword;
    await _saveWifi(ssid: newSsid, hidden: newHidden, password: newPass);
    if (changes.clientLimit != null) await setClientLimit(changes.clientLimit!);
  }

  @override
  Future<void> reboot() async {
    // Not defined in STRICT contract; do not invent
    throw Exception(_c.errors['unsupported_theme'] ?? 'UNSUPPORTED_THEME');
  }
}
