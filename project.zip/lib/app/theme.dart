import 'package:flutter/material.dart';

class ShabkatiTheme {
  static const _radius = 16.0;

  static final light = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorSchemeSeed: const Color(0xFF2E7DFF),
    fontFamily: 'Roboto',
    scaffoldBackgroundColor: const Color(0xFFF8F9FC),
    cardTheme: CardTheme(
      elevation: 1.5,
      margin: const EdgeInsets.all(12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(_radius)),
    ),
    inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
  );

  static final dark = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorSchemeSeed: const Color(0xFF2E7DFF),
    scaffoldBackgroundColor: const Color(0xFF0F1115),
    cardTheme: CardTheme(
      elevation: 1.5,
      margin: const EdgeInsets.all(12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(_radius)),
    ),
    inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
  );
}
