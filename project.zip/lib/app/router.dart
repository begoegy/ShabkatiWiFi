import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/connection/presentation/landing_page.dart';
import '../features/auth/presentation/login_page.dart';
import '../features/dashboard/presentation/dashboard_page.dart';
import '../features/settings/presentation/about_page.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (_, __) => const LandingPage()),
    GoRoute(path: '/login', builder: (_, state) => const LoginPage()),
    GoRoute(path: '/dashboard', builder: (_, __) => const DashboardPage()),
    GoRoute(path: '/about', builder: (_, __) => const AboutPage()),
  ],
);
