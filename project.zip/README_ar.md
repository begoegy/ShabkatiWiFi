# Shabkati WiFi – SalemForNet

تطبيق Flutter احترافي لإدارة الراوتر (Tomato) محليًا 100% بدون أي تتبع أو خوادم خارجية.
- لغة وواجهة عربية RTL بالكامل.
- تصميم M3 احترافي (فاتح/داكن) + Skeleton/Empty/Error.
- استخراج الجيتواي تلقائيًا من نظام أندرويد ≤ 2 ثانية عبر قناة منصّة (Kotlin).
- زر **حفظ** واحد لتطبيق التغييرات دفعة واحدة + **Rollback** برمجي عند الفشل (حسب العقد).
- طبقة **RouterDriver** موحّدة تعتمد حصريًا على محتوى `assets/router/tomato_contract.yaml` (STRICT).

## الإصدارات المثبّتة
- Flutter: 3.24.3
- Dart: 3.5.x
- Gradle Wrapper: 8.7
- Android Gradle Plugin (AGP): 8.6.1
- JDK: 17
- minSdk: 24 / targetSdk & compileSdk: 34

## الأذونات
- ACCESS_FINE_LOCATION: مطلوبة على Android 10+ لقراءة معلومات Wi-Fi لاستخراج DHCP Gateway.
- ACCESS_WIFI_STATE / CHANGE_WIFI_STATE / INTERNET

## البناء
```bash
flutter pub get
dart run flutter_launcher_icons
flutter analyze
flutter build apk --release --split-per-abi
```

## الحقوق
© 2025 SalemForNet. جميع الحقوق محفوظة.  
Shabkati WiFi™ علامة مملوكة لـ SalemForNet.
